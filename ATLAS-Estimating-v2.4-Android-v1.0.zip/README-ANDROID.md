# ATLAS Estimating v2.4 — Android Add-On

This is the Android launcher for the existing ATLAS Estimating v2.4 project.

It does not change the estimating engine.

## Adds
- Chrome install / Add to Home Screen flow
- App-style standalone launch
- Touch/pinch-friendly viewport
- Portrait and landscape support
- Android keyboard viewport handling
- Offline reopening after first successful online load
- OPEN SAVED directly beside OPEN
- Open Saved Project inside OPTIONS
- Same existing ATLAS IndexedDB saved-project system

## Add these files beside the current ATLAS files
- android.html
- manifest-android.webmanifest
- sw-android.js
- atlas-android-192.png
- atlas-android-512.png

Keep your existing:
- index.html
- app.js
- style.css
- quantities.js
- door-sketch.js

## Install
Open `android.html` in Chrome, then use INSTALL APP or Chrome ⋮ → Install app / Add to Home screen.

Open it online once so the core app files cache for offline reopening.

Saved projects remain local to that Android browser/device. Use ATLAS backups when moving jobs between devices.
